*PADS-LIBRARY-PART-TYPES-V9*

XT30UPB-F XT30UPBF I CON 7 1 0 0 0
TIMESTAMP 2026.06.13.05.43.08
"TME Electronic Components Part Number" 
"TME Electronic Components Price/Stock" 
"Manufacturer_Name" Amass
"Manufacturer_Part_Number" XT30UPB-F
"Description" Socket; DC supply; XT30; female; PIN: 2; on PCBs; THT; Colour: yellow
"Datasheet Link" https://www.tme.eu/Document/81f11ca924696756331f21b972812074/XT30PB-F.pdf
"Geometry.Height" 9.4mm
GATE 1 2 0
XT30UPB-F
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
15932025/2084239/2.50/2/3/Connector
